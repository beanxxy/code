(function(a){
	alert("test123"+a);
})