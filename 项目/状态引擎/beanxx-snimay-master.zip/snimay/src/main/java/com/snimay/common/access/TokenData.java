package com.snimay.common.access;

/**   
 * : 加密数据模板 
 * @title      : TokenData.java
 * @package    : com.snimay.common.access
 * @author     : xxy
 * @date       : 2018年8月7日 上午10:15:01
 * @version    : V1.0   
 */
public class TokenData {
	public long userid;
	public long time;
	public String ip;
}
