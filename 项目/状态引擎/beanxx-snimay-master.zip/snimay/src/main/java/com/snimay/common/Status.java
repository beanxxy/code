package com.snimay.common;

 
/**   
 * : 系统基础参数定义
 * @title      : Status.java
 * @package    : com.snimay.common
 * @author     : xxy
 * @date       : 2018年8月7日 上午10:15:39
 * @version    : V1.0   
 */
public class Status {
    //状态码
	
    public final static String SUCCESS 		= "000";
    public final static String FAIL 		= "001";
    public final static String NO_LOGIN 	= "003";
    public final static String NO_PRIVILEGE = "004";

    //资源状态
    public final static int DELETE 	= 0;
    public final static int ENABLE 	= 1;
    public final static int DISABLE = 2;
}
