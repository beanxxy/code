(function(){
	Get("/user/out");
	location.reload();
})