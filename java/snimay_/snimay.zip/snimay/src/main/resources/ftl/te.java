package com.snimay.app.vo;
import com.snimay.heibernate.Annotation.field;
public class te {
	public void hello(){
		
	}
}
