package com.snimay.app.process;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.activiti.engine.delegate.Expression;
public class Helloservice2 implements JavaDelegate{
	
	/*
	 * private Expression fieldName1; private Expression fieldName2;
	 */
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("---------------------------------------------");
		//System.out.println(fieldName1.getExpressionText());
		System.out.println(execution.getCurrentActivityName());
		System.out.println("Hello Service " + this.toString()
				+ "Is Saying Hello To Every One !");
		//execution.getVariable(variableName)
		execution.setVariable("var1", new StringBuffer("test1").reverse().toString());
		System.out.println("---------------------------------------------");
		System.out.println();

	}

}
