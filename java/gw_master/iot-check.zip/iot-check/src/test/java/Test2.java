import java.util.Date;

public class Test2 {
	/**
	 * ABCD
	 * BADC
	 * CDAB
	 * DCBA 
	 *
	 * 
	 */
	public static byte[] encode(String value,String model,String type) {
		return null;	
	}
	public static String decode(byte[] value,String model,String type) {
		return "";
	}
	public static void main(String[] arg) throws InterruptedException {
		for(int i=0;i<1000;i++) {
			System.out.println(new Date().getTime());
			Thread.sleep(1000);
		}
		
	}
}
