package com.iot.gateway.core.enums;

/**
 * @author bean
 * 2020年12月25日
 */
public enum State {
	//空闲
	free,
	//错误
	error,
	//忙碌
	busy
}
