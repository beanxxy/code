package com.iot.check;

import com.iot.gateway.core.Ioinfo;

/**
 * @author bean
 * 
 */
public class AlarmInfo extends Ioinfo{

	@Override
	public void change(String value) { 
	}

	@Override
	public void call(String value) { 
	} 
}
