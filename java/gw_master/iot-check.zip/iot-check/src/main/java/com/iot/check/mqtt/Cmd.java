package com.iot.check.mqtt;

public class Cmd {
	public String id;
	public int type;
	public String cmd;
	public String cmdParam;
	public Long cmdId;
}
