import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;

import gateway.core.config.AddressConfig;
import gateway.core.imp.ClientTcp;
import gateway.core.redis.Config;

public class pp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AddressConfig address = new AddressConfig();
		address.protocal = "mc";
		address.ip 	     = "172.28.12.18";
		address.port	 = 8000;
		address.dataModel= "bit";
		address.dataAddr = "D2250-0";
		ClientTcp cp = new ClientTcp();
		
		Gson gson = new Gson();
		 Map<String,String> map = new HashMap();
		 map.put("deviceId", address.deviceId);
		 map.put("parentName", address.parentName);
		 map.put("estimateName", address.estimateName);
		 map.put("estimateValue", "1");
		 map.put("datatime", (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date())); 
		 System.out.println("SSs:"+"1");
		 String sjosn = gson.toJson(map);
		 Config.jedis.lpush("gateway:device:state:historical-data",sjosn); 
		
		 
		 System.out.println("xxx");
		//cp.batchWrite(address, "0"); 
	}

}
