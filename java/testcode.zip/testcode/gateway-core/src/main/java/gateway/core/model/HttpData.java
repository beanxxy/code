package gateway.core.model;

public class HttpData {
	public String url;
	public String path;
	public String port;
	public String data;
	public String method;
}
