package gateway.core.config;

public class ServerConfig {
	public int id;
	public int port;
	public String dataAddr;
	public int type;
	public int state;
}
