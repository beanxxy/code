package gateway.core.config;

public class DataModel {
	public int id;
	public int index;
	public int length;
	public String group;
	public String name;
	public String datatype;
	
}
